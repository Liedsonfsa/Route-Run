from servidor import Servidor


def main():
    servidor = Servidor()
    servidor.ligar_servidor()


if __name__ == "__main__":
    main()
